﻿using System.Web.UI;

namespace TestASPNETv0._0.Account
{
    public partial class ResetPasswordConfirmation : Page
    {
    }
}