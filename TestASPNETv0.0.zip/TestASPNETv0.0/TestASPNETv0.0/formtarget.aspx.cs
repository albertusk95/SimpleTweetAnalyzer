﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

using LinqToTwitter;


namespace TestASPNETv0._0
{
    public partial class formtarget : System.Web.UI.Page
    {

        /**
         * inisiasi autentikasi
         */
        private SingleUserAuthorizer authorizer =
           new SingleUserAuthorizer
           {
               CredentialStore = new
              SingleUserInMemoryCredentialStore
               {
                   ConsumerKey =
                 "",
                   ConsumerSecret =
                 "",
                   AccessToken =
                 "",
                   AccessTokenSecret =
                 ""
               }
           };


        /*
         * atribut 
         */
        private List<Status> currentTweets = new List<Status>();


        /*
         * masuk ke prosedur ini setelah button ExtractTwitter diklik
         */
        protected void Page_Load(object sender, EventArgs e)
        {

            namelab.Text = ((TextBox)Page.PreviousPage.FindControl("tipetweet")).Text;

            currentTweets = SearchTwitter(((TextBox)Page.PreviousPage.FindControl("tipetweet")).Text);

            int cellCtr;
            int tweetCount = 1;

            foreach (var tweet in currentTweets)
            {
                // Create new row and add it to the table.
                TableRow tRow = new TableRow();
                TweetTable.Rows.Add(tRow);
                for (cellCtr = 0; cellCtr < 3; cellCtr++)
                {
                    // Create a new cell and add it to the row.
                    TableCell tCell = new TableCell();
                    if (cellCtr == 0)
                    {
                        tCell.Text = tweetCount.ToString();
                        tweetCount++;
                        //tRow.Cells.Add(tCell);
                    }
                    else if (cellCtr == 1)
                    {
                        tCell.Text = tweet.Text;
                        //tRow.Cells.Add(tCell);
                    }
                    else
                    {
                        //tRow.Cells.Add(tCell);
                        System.Web.UI.WebControls.HyperLink h = new HyperLink();
                        h.Text = "https://twitter.com/intent/retweet?tweet_id=" + tweet.StatusID.ToString();
                        h.NavigateUrl = "https://twitter.com/intent/retweet?tweet_id=" + tweet.StatusID.ToString();
                        tCell.Controls.Add(h);
                    }
                    tRow.Cells.Add(tCell);
                }
            }

        }

        /*
        private void GetMostRecent200HomeTimeLine()
        {
            var twitterContext = new TwitterContext(authorizer);

            var tweets = from tweet in twitterContext.Status
                         where tweet.Type == StatusType.Home && 
                         tweet.Count == 100                         
                         select tweet;

            currentTweets = tweets.ToList();
            
        }
        */


        /**
         * METHODS
         */
        private List<Status> SearchTwitter(string searchTerm)
        {
            var twitterContext = new TwitterContext(authorizer);

            var srch = Enumerable.SingleOrDefault((from search in twitterContext.Search
                                           where search.Type == SearchType.Search &&
                                           search.Query == searchTerm &&
                                           search.Count == 100
                                           select search));

            if (srch != null && srch.Statuses.Count > 0)
            {
                return srch.Statuses.ToList();
            }

            return new List<Status>();      //list kosong jika tidak ada tweet yang mengandung keyword 
        }
       
    }
}